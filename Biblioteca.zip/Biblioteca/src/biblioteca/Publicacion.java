
package biblioteca;

import java.util.Objects;

public abstract class Publicacion {
    private String titulo;
    private int anioPublicacion;

    public Publicacion(String titulo, int anioPublicacion) {
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()){
            return false;
        }
        Publicacion otra = (Publicacion) obj;
        return anioPublicacion == otra.anioPublicacion && titulo.equals(otra.titulo);
    }
    
    @Override
    public int hashCode(){
    return Objects.hash(anioPublicacion, titulo);
    }

    @Override
    public String toString() {
        return "Publicacion{" + "titulo=" + titulo + ", anioPublicacion=" + anioPublicacion + '}';
    }
    
    
}
