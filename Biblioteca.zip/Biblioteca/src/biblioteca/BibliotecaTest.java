
package biblioteca;

public class BibliotecaTest {

    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();

       
        cargarBiblioteca(biblioteca);
        biblioteca.mostrarPublicaciones();
        

        biblioteca.leerPublicaciones();
    }
    
    private static void cargarBiblioteca(Biblioteca biblioteca) {
        try {
            
            biblioteca.agregarPublicacion(new Libro("La niebla", 900, "Stephen king", Genero.FICCION));
            biblioteca.agregarPublicacion(new Libro("spider-man 1", 2022, "joaquin diaz", Genero.CIENCIA));

            biblioteca.agregarPublicacion(new Revista("National Geographic", 2023, 345));
            biblioteca.agregarPublicacion(new Ilustracion("La noche estrellada", 1880, "Van Gogh", 150, 200));
        } catch (PublicacionExistenteException e) {
            System.out.println("Error al agregar publicacion: " + e.getMessage());
        }
    }
}
