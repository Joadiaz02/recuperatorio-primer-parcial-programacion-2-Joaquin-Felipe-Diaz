
package biblioteca;

class Revista extends Publicacion implements Leible {
    private int numeroEdicion;

    public Revista(String titulo, int anioPublicacion, int numeroEdicion) {
        super(titulo, anioPublicacion);
        this.numeroEdicion = numeroEdicion;
    }

    @Override
    public void leer() {
        System.out.println("Leyendo " + getTitulo());
    }

    @Override
    public String toString() {
        return "Revista{" + "numeroEdicion=" + numeroEdicion + super.toString();
    }

   
}
