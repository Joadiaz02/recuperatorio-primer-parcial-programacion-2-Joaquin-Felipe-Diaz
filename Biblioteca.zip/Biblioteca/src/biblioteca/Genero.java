package biblioteca;


enum Genero {
    FICCION, NO_FICCION, CIENCIA, HISTORIA;
}
