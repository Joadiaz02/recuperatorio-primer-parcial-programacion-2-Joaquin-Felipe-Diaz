package biblioteca;


public class PublicacionExistenteException extends Exception {
    public static final String MESSAGE = "Ya existe esa publicacion";

    public PublicacionExistenteException() {
        super(MESSAGE); 
    }
}
