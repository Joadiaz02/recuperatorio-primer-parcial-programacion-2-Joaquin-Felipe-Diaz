package biblioteca;

import java.util.ArrayList;
import java.util.List;

public class Biblioteca {
    private List<Publicacion> publicaciones;

    public Biblioteca() {
        this.publicaciones = new ArrayList<>();
    }

    public void agregarPublicacion(Publicacion publicacion) throws PublicacionExistenteException {
    if (publicacion == null) {
        throw new IllegalArgumentException("Argumento invalido");
    }
    int i = 0;
    while (i < publicaciones.size()) {
        if (publicaciones.get(i).equals(publicacion)) {
            throw new PublicacionExistenteException();
        }
        i++;
    }
    publicaciones.add(publicacion);
}

    public void mostrarPublicaciones() {
        for (Publicacion publicacion : publicaciones) {
            System.out.println(publicacion);
        }
    }

    public void leerPublicaciones() {
        for (Publicacion publicacion : publicaciones) {
            if (publicacion instanceof Leible lee) {
                lee.leer();
            } 
               System.out.println("Esta publicacion no se puede leer" + publicacion.getTitulo());
            
        }
    }
}


